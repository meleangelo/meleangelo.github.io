**********************************
* WEB EXAMPLE                    *
* Poisson Indices of Segregation *
* by Angelo Mele                 *
* this version: 01/29/2010       *
**********************************


This folder contains an example that computes the indices of 
segregation developed in Mele (2010), "Poisson Indices of 
Segregation".

In order to run the code you need to install R on your pc and
several packages for the analysis of spatial point processes.
In the following I assume that you have no familiarity with R
and I drive you through each single step of the installation 
process. If you are familiar with the software it should not
be too difficult to install all the packages.



******************************
* STEP 1: Installation of R. *
******************************

- go to the website http://www.r-project.org/
- click on CRAN
- choose the mirror website closest to you. I usually choose 
  the one by Iowa State. click on the link
- choose the Windows version, by clicking on the link "Windows".
  (I have Windows Vista on my laptop. Users of Linux and Mac should
   download the version for their operative systems.)
- click on the link "base"
- you are directed to the download page, where you can download the 
  R installer for the most recent version. Click to start downloading.
- Once the download is done, click on the .exe file and install it on
  your computer.



************************************
* STEP 2: install spatial packages *
************************************

- open R
- install the package "splancs". type the following

   install.packages("splancs", dependencies=TRUE)

- select the mirror site
- install the package "spatstat". type the following

   install.packages("spatstat", dependencies=TRUE)



*************************************************************
* STEP 3: install tools for installing packages from source *
*************************************************************

- go to the webpage
  http://www.murdoch-sutherland.com/Rtools/

- download the latest version of the Rtools
- install it by clicking on it.

- download and install the Inno Setup installer from
  http://www.jrsoftware.org/download.php/is.exe

- I assume you have Miktek installed. If you don't
  you need to download it and install it.



**********************************
* STEP 4: install "myspatkernel" *
**********************************

- now you need to install the package "myspatkernel", which is 
  a modified version of the package "spatialkernel" by Diggle, 
  Zheng and Durr (2005). The documentation of the original package
  is here
  http://cran.r-project.org/web/packages/spatialkernel/spatialkernel.pdf

- to install "myspatkernel", you need to download it from my webpage.
  htpp:/netfiles.uiuc.edu/amele2/www/myspatkernel.zip

- save it in the following directory
  c:/tempspat

- unzip the file

- The following instructions are for Windows Vista
- go on start menu -> All Programs -> Accessories -> Command Prompt 
- the windows shell opens up
- type 
  cd c:\Program Files\R\R-2.10.1\bin\

- type
  PATH=c:\Rtools\bin;c:\perl\bin;c:\Rtools\MinGW\bin;c:\texmf\miktex\bin;c:\Program Files/HTML Help Workshop;c:\Program Files/R/R-2.10.1/bin;c:\windows;c:\windows\system32

- If you installed the Rtools or Perl in different directories, 
  the above command will not work. You need to check that these
  folders exist.

- type
  R CMD INSTALL c:/tempspat/myspatkernel

- this should install the library "myspatkernel" in your R

- to call the library from R you just type
  library(myspatkernel)





Now you are ready to run the example.
You can just type in R

source("c:/nameoffolder/web_example.txt")